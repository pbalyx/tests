network_name = "Réseau Bassin d'Aubenas";
//test_button = true;
//network_router = true;
//mapCenter = "45.1447, 5.7266"; 
mapCenter = "auto";
zoom = "13";
